
function start_chat(url)
{
	//alert(url);
	
	var name=jQuery("#inputname").val();
	var email=jQuery("#inputemail").val();
	//alert(name);
	jQuery.ajax({
         type : "post",
         dataType :"json",
         url :url,
         data : {action: "start_chat", name:name,email:email},
         success: function(d) {
			 
			 
			
			 localStorage.setItem("email", d.email);
			 localStorage.setItem("admin_email", d.admin_url);
			 var email=localStorage.getItem("email");
			
			 
		     //document.getElementById("result").innerHTML ="<div>"+d.message+"</div>";
				//alert();
				jQuery(".chat_form").hide();
				jQuery(".chatbox").show(); 
			 
			location.reload();
			
         }
      });
}


function send_message(url)
{
	
	var from_mgs=localStorage.getItem("email");
	//var to_mgs=localStorage.getItem("admin_email");
	var mgs=jQuery("#idsend").val();
	
	//alert(from_mgs);
	//alert(to_mgs);
	
	
	
	jQuery.ajax({
		type:"post",
		datatype:"json",
		url:url,
		data:{action:"send_message",from_mgs:from_mgs,mgs:mgs},
		success:function(d){
			
			console.log(d);
			
				
			//alert(d);
			//var dd=JSON.parse(d);
			//console.log(dd);
			
			//return false;
		
			location.reload();
		}
		
	});
	
}

