function send_admin_message(url,email,id)
{
	//alert(url);
	//alert(email);
	var mgs=jQuery("#adminsend"+id+"").val();
  
	 //return false;
	jQuery.ajax({
         type : "post",
         dataType :"json",
         url :url,
         data : {action: "admin_send_mgs", to_mgs:email,mgs:mgs},
         success: function(d) {
			 
			 location.reload();
			}
      });
}