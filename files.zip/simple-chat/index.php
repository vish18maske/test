<?php

/*
Plugin Name: Simple Chat Plugin
Description: This is simple chat plugin admin can chat with multiple visitors and visitors can chat with admin.
version:5.0
Author: Brainstromforce 
*/


/*****************************css and js include ******************************/
//require_once( ABSPATH . "wp-includes/pluggable.php" );
function include_css_js() {
wp_register_style('main_css', plugins_url('assest/css/main.css',__FILE__ ));
wp_enqueue_style('main_css');


wp_register_style('bootstrap_css', plugins_url('assest/css/bootstrap.css',__FILE__ ));
wp_enqueue_style('bootstrap_css');

wp_register_style('fontawesome_css', plugins_url('assest/css/font-awesome.min.css',__FILE__ ));
wp_enqueue_style('fontawesome_css');

wp_register_script( 'main_js', plugins_url('assest/js/main.js',__FILE__ ));
wp_enqueue_script('main_js');

wp_register_script( 'front_js', plugins_url('assest/js/front.js',__FILE__ ));
wp_enqueue_script('front_js');


wp_register_script( 'bootstrap_js', plugins_url('assest/js/bootstrap.js',__FILE__ ));
wp_enqueue_script('bootstrap_js');


wp_localize_script( 'my_voter_script', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));        
wp_enqueue_script('my_voter_script');
}
add_action( 'admin_init','include_css_js');


/****************************** on activating the plugin**********************************/
function mem_initiate_plugin(){
	
	 
	/// IF PHP >5.3 don't activate plugin
	/* if (defined('PHP_VERSION') && version_compare(PHP_VERSION, 5.3, '<')){
		deactivate_plugins(plugin_basename( __FILE__ ));
		die('Ultimate Membership Pro requires PHP version greater than 5.3, Your current PHP is v.' . PHP_VERSION . ' . Update Your PHP and try again!');
	} */ 
	 
	require_once MEM_PATH . 'core/mem_Db.class.php';
	
	Mem_Db::create_tables();
	Mem_Db::create_pages();
	//Mem_Db::admin_menu();
        	
	
}
register_activation_hook( __FILE__, 'mem_initiate_plugin' );





/************************************** setting path **********************************/

if (!defined('MEM_PATH')){
	define('MEM_PATH', plugin_dir_path(__FILE__));
}


/************************************** plugin url ************************************/

if (!defined('MEM_URL')){
	define('MEM_URL', plugin_dir_url(__FILE__));
}

if (!defined('MEM_PROTOCOL')){
	if (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) || isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https'){
		define('MEM_PROTOCOL', 'https://');
	} else {
		define('MEM_PROTOCOL', 'http://');	
	}
}




/*********************************** Admin Menu Creation ********************************/

add_action('admin_menu', 'my_menu');

function my_menu() {
    add_menu_page('Simple chat', 'Simple Chat', 'manage_options', 'simple-chat-slug', 'pages_func');
	
}



/*********************************************** Pages Menu ****************************************************************/

function pages_func()
{
	global $wpdb;
	$ajax_url=admin_url('admin-ajax.php');
	$table=$wpdb->prefix."chat_users";
    $data=$wpdb->get_results("select * from $table");
	?>
    <div><h1 style="background: #23282d;color: white;padding: 15px;">Visitors ChatRoom</h1></Div>
	<div id="accordion" role="tablist">
	<?php
	foreach($data as $d)
	{
		
		
		?>
		 <div class="card" style="float:left;">
		<div class="card-header" role="tab" id="heading<?php echo $d->id;?>">
		
		<h5 class="mb-0" style="background:#23282d;padding: 20px;">
        <a data-toggle="collapse" href="#collapse<?php echo $d->id;?>" role="button" style="color:white" aria-expanded="true" aria-controls="collapseOne">
           <?php echo $d->name."  ".$d->email;?>
        </a>
      </h5>
	   </div>
	   
	   <div id="collapse<?php echo $d->id;?>" class="collapse" role="tabpanel" aria-labelledby="heading<?php echo $d->id;?>" data-parent="#accordion">
      <div class="card-body">
       <?php 
	     $admin_url=get_bloginfo('admin_email');
	      $table1=$wpdb->prefix."chat_mgs";
	      $data1=$wpdb->get_results("select * from  $table1 where from_mgs='$d->email' AND message !=''");
		  
		 // print_r($data1);
		  
		  foreach($data1 as $d1)
		  {
			
			  
			  //echo $d1->from_mgs;
			  //echo $admin_url;
			  if($d1->flag == 0)
			  {
				    
				echo "<p style='color:green'>Admin:".$d1->message."</p>";  
			  }
			  else
			  {
				
			  echo "<p style='color:red'>Visitor:".$d1->message."</p>";
			  }
			  
			  
		  }
		  
		  
	   
	   ?>
	   <input type="text" placeholder="Send Message" id="adminsend<?php echo $d->id;?>"/>
	   <button onclick="send_admin_message('<?php echo $ajax_url;?>','<?php echo $d->email;?>','<?php echo $d->id;?>')" class="btn btn-success">Send</button>
      </div>
    </div>
		</div>

		<?php
		
	}
	?>
	
	</div>
	<?php
	//print_r($data);
	
}

function chat_display()
{
	
	$ajax_url=admin_url('admin-ajax.php');
	?>
	<link rel="stylesheet" href="<?php echo MEM_URL;?>/assest/css/front.css">
	<script src="<?php echo MEM_URL;?>/assest/js/front.js"></script>
	<div class="chat_form">
  <div class="form-group">
    <label for="exampleInputPassword1">Name</label>
    <input type="text" class="form-control" id="inputname" placeholder="Name">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="inputemail" aria-describedby="emailHelp" placeholder="Enter email">
   
  </div>
 
  <button type="submit" class="btn btn-primary" onclick="start_chat('<?php echo $ajax_url;?>')">Start Chat</button>
   </div>
  
   <div style="display:none;" class="chatbox">
   
   <div id="result" style="margin-bottom: 14px;background: #00000026;padding: 23px 0px 23px 10px;">
   
   </div>
   <input type="text" placeholder="Send Message" id="idsend" style="margin-bottom: 14px;"/><br>
   <button onclick="send_message('<?php echo $ajax_url;?>')" class="btn btn-success">Send</button>
   </div>

<script>



/*  var time = new Date().getTime();
     jQuery(".chatbox").bind("mousemove keypress", function(e) {
         time = new Date().getTime();
     });

     function refresh() {
         if(new Date().getTime() - time >= 5000) 
             window.location.reload(true);
         else 
             setTimeout(refresh, 1000);
     }

     setTimeout(refresh, 1000);  */
get_current_cdata();
function get_current_cdata()
{
//localStorage.removeItem("email");
var email=localStorage.getItem("email");
//alert(email);
if(email != null)
{
	

	jQuery(".chat_form").hide();
	jQuery(".chatbox").show();
	
	 jQuery.ajax({
		type:"post",
		datatype:"json",
		url:"<?php echo $ajax_url;?>",
		data:{action:"get_cdata",email:email},
		success:function(d){
			
			console.log(d);
			//alert(d);
			var dd=JSON.parse(d);
			//console.log(dd);
			
			//return false;
			for(var i=0;i<dd.length;i++)
			{
				console.log(dd[i]);
				if(dd[i].flag==1)
				{
					
				jQuery("#result").append("<div style='color:green'>Me:  "+dd[i].message+"</div>");
				}
				else
				{
					
				jQuery("#result").append("<div style='color:red'>Admin:   "+dd[i].message+"</div>");	
				}
			}
		}
		
	}); 
	
	
}
else
{
	//alert("its null");
}



}
</script>


	<?php
}

add_shortcode("chat_dis","chat_display");


add_action("wp_ajax_start_chat", "start_chat");
add_action("wp_ajax_nopriv_start_chat", "start_chat");

function start_chat()
{
	
	$name=$_POST['name'];
	$email=$_POST['email'];
	$flag=0;
	global $wpdb;
	$table=$wpdb->prefix."chat_users";
	$table1=$wpdb->prefix."chat_mgs";
	$dt=[];
	$data=$wpdb->get_results("select * from $table");
	$data1=$wpdb->get_results("select * from $table1");
	  
	
      foreach($data as $d)
		  {
				if($d->email == $email)
				{
					$flag=1;
					$dt['email']=$d->email;
				}					      	
		
		  }
	 
	 if($flag==1)
	  {
		  
		  foreach($data1 as $d1)
		  {
		  if($d1->from_mgs == $email)
				{
				 
				 $admin_url=get_bloginfo('admin_email');
				 $dt['admin_url']=$admin_url;		
				 $dt['from_mgs']=$d1->from_mgs;		
				 $dt['to_mgs']=$admin_url;		
				 $dt['message']=$d1->message;		
				 $dt['flag']=$d1->flag;		
					
				}
		  }
		echo json_encode($dt);
	  }
	  else
	  {
		 $insert=$wpdb->insert($table,
		array("name"=>$name,"email"=>$email),
		array("%s","%s")
		);  
       $admin_url=get_bloginfo('admin_email'); 
		
	     if($insert)
		 {
		$wpdb->insert($table1,
				  array("from_mgs"=>$email,"to_mgs"=> $admin_url,"message"=>"","flag"=>1),
				  array("%s","%s","%s","%d")
			); 
		 }
			     $dt['email']=$email;		
			     $dt['admin_url']=$admin_url;		
				 			
		echo json_encode($dt);
	  }  
	die();
}


add_action("wp_ajax_send_message", "send_message");
add_action("wp_ajax_nopriv_send_message", "send_message");

function send_message()
{
	global $wpdb;
	$admin_url=get_bloginfo('admin_email');
	$from_mgs=$_POST['from_mgs'];
	$to_mgs=$admin_url;
	$mgs=$_POST['mgs'];
	$table=$wpdb->prefix."chat_mgs";
	$wpdb->insert($table,
				  array("from_mgs"=>$from_mgs,"to_mgs"=>$to_mgs,"message"=>$mgs,"flag"=>1),
				  array("%s","%s","%s","%d")
	); 
	
	
    $table1=$wpdb->prefix."chat_mgs";
	
	$data=$wpdb->get_results("select * from $table1 where from_mgs='$email'");
	
	echo json_encode($data);
	
	
	
	die();
	
	
}

add_action("wp_ajax_get_cdata", "get_cdata");
add_action("wp_ajax_nopriv_get_cdata", "get_cdata");

function get_cdata()
{
	global $wpdb;
	
	$email=$_POST['email'];
	$table=$wpdb->prefix."chat_mgs";
	
	$data=$wpdb->get_results("select * from $table where from_mgs='$email' AND message != ''");
	
	echo json_encode($data);
	
	die();
	
	
}

add_action("wp_ajax_admin_send_mgs", "admin_send_mgs");
add_action("wp_ajax_nopriv_admin_send_mgs", "admin_send_mgs");
function admin_send_mgs()
{
	global $wpdb;
	$table=$wpdb->prefix."chat_mgs";
	$admin_email=get_bloginfo("admin_email");
	$from_mgs=$_POST['to_mgs'];
	$mgs=$_POST['mgs'];
	
	$wpdb->insert($table,
				  array("from_mgs"=>$from_mgs,"to_mgs"=>$admin_email,"message"=>$mgs,"flag"=>0),
				  array("%s","%s","%s","%d")
	);
	
	//echo json_encode("vishal");
	die();
}

