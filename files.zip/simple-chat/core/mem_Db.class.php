<?php
if (!class_exists('Mem_Db')):
	
class Mem_Db{
	
	public function __construct(){}
	
	
	
	public static function create_tables(){
	
		/*
		 * @param none
		 * @return none
		 */
		global $wpdb;
		
		
		/// ihc_cheat_off
		$table_name = $wpdb->prefix . 'chat_users';
		if ($wpdb->get_var("show tables like '$table_name'")!=$table_name){
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$sql = "CREATE TABLE $table_name (
						id INT(11)  AUTO_INCREMENT PRIMARY KEY,
						name VARCHAR(50) NOT NULL,
						email VARCHAR(50) NOT NULL
			);";
			dbDelta($sql);			
		}	
		
		$table_name = $wpdb->prefix . 'chat_mgs';
		if ($wpdb->get_var("show tables like '$table_name'")!=$table_name){
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$sql = "CREATE TABLE $table_name (
						id INT(11) AUTO_INCREMENT PRIMARY KEY,
						from_mgs VARCHAR(500),
						to_mgs VARCHAR(40) NOT NULL,
						message VARCHAR(1000) NOT NULL,
						flag int(20) NOT NULL
						
			);";
			dbDelta($sql);			
		}	
		
		

				
		
				
				
						
												 
	}
	
	public static function create_pages()
	{
		
		
$title ="simple_chat";
$post = get_page_by_title( $title, 'OBJECT', 'page' );

		
		
	if(NULL==$post)
	{
	$new_post = array(
          'comment_status' => 'closed',
          'ping_status' =>  'closed' ,
          'post_author' => 1,
          'post_date' => date('Y-m-d H:i:s'),
          'post_name' => 'simple_chat',
          'post_status' => 'publish' ,
          'post_title' => 'simple_chat',
		  'post_content'=>'[chat_dis]',
          'post_type' => 'page',
    );  
    //insert page and save the id
    $newvalue = wp_insert_post( $new_post, false );
    //save the id in the database
    update_option( 'chatpage', $newvalue );
	}
	
	
	
	
	
	}
	
	

	

		
		
	}
		
	
	
endif;


